import sqlite3
import os
import threading
import atexit
from contextlib import contextmanager
from typing import Optional, Any, Dict, List, Set
from datetime import datetime

class DatabaseManager:
    """SQLite database manager for ZKTeco application"""
    
    def __init__(self, db_path: str = "zkteco_app.db"):
        env_db_path = os.environ.get("ZKTECO_DB_PATH")
        resolved_path = env_db_path if env_db_path else db_path

        if not os.path.isabs(resolved_path):
            base_dir = os.path.dirname(os.path.abspath(__file__))
            resolved_path = os.path.join(base_dir, resolved_path)

        db_directory = os.path.dirname(resolved_path)
        if db_directory:
            try:
                os.makedirs(db_directory, exist_ok=True)
            except OSError as exc:
                raise RuntimeError(
                    f"Unable to create database directory '{db_directory}': {exc}"
                ) from exc

        self.db_path = resolved_path
        self._local = threading.local()
        self._connections: Set[sqlite3.Connection] = set()  # Track all connections for cleanup
        self._lock = threading.Lock()

        # Register cleanup on exit
        atexit.register(self.close_all_connections)

        self.init_database()
    
    def get_connection(self) -> sqlite3.Connection:
        """Get thread-local database connection"""
        if not hasattr(self._local, 'connection') or self._local.connection is None:
            conn = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
                timeout=30.0
            )
            # Enable performance-oriented pragmas. WAL improves concurrent access, while
            # NORMAL synchronous/cache/temp settings trade a little durability for speed.
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
            conn.execute("PRAGMA cache_size = 10000")
            conn.execute("PRAGMA temp_store = MEMORY")
            conn.row_factory = sqlite3.Row

            # Store connection in thread-local storage
            self._local.connection = conn

            # Track connection for cleanup
            with self._lock:
                self._connections.add(conn)

        return self._local.connection
    
    @contextmanager
    def get_cursor(self):
        """Context manager for database operations"""
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            yield cursor
        except Exception:
            conn.rollback()
            raise
        else:
            conn.commit()
        finally:
            cursor.close()
    
    def init_database(self):
        """Initialize database tables"""
        with self.get_cursor() as cursor:
            # Devices table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS devices (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    ip TEXT NOT NULL,
                    port INTEGER DEFAULT 4370,
                    password INTEGER DEFAULT 0,
                    timeout INTEGER DEFAULT 10,
                    retry_count INTEGER DEFAULT 3,
                    retry_delay INTEGER DEFAULT 2,
                    ping_interval INTEGER DEFAULT 30,
                    force_udp BOOLEAN DEFAULT FALSE,
                    is_active BOOLEAN DEFAULT TRUE,
                    device_info TEXT, -- JSON string for device info
                    serial_number TEXT UNIQUE,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Users table with sync tracking
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    device_id TEXT,
                    serial_number TEXT,
                    privilege INTEGER DEFAULT 0,
                    group_id INTEGER DEFAULT 0,
                    card INTEGER DEFAULT 0,
                    password TEXT DEFAULT '',
                    is_synced BOOLEAN DEFAULT FALSE,
                    synced_at DATETIME NULL,
                    external_user_id INTEGER NULL,
                    avatar_url TEXT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Attendance logs table with sync tracking and duplicate prevention
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS attendance_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    device_id TEXT,
                    serial_number TEXT,
                    timestamp DATETIME NOT NULL,
                    method INTEGER NOT NULL, -- 1: fingerprint, 4: card
                    action INTEGER NOT NULL, -- 0: checkin, 1: checkout, 2: overtime start, 3: overtime end, 4: unspecified
                    raw_data TEXT, -- JSON string for raw attendance data
                    sync_status TEXT DEFAULT 'pending', -- pending, synced, skipped
                    is_synced BOOLEAN DEFAULT FALSE, -- kept for backward compatibility
                    synced_at DATETIME NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    CONSTRAINT unique_attendance UNIQUE(user_id, device_id, timestamp, method, action)
                )
            ''')
            
            # App settings table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS app_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    description TEXT,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            # Migrate existing tables to add new columns
            self._migrate_devices_table(cursor)
            self._migrate_users_table(cursor)
            self._migrate_attendance_logs_table(cursor)
            
            # Create indexes for better performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_users_device_id ON users(device_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_users_sync_status ON users(is_synced)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_user_id ON attendance_logs(user_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_device_id ON attendance_logs(device_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_timestamp ON attendance_logs(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_sync_status ON attendance_logs(is_synced)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_sync_status_new ON attendance_logs(sync_status)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_date_action ON attendance_logs(DATE(timestamp), action)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_attendance_user_date ON attendance_logs(user_id, DATE(timestamp))')
            
            print(f"Database initialized at: {os.path.abspath(self.db_path)}")
    
    def _migrate_devices_table(self, cursor):
        """Migrate existing devices table to add serial_number column"""
        # Check if column already exists
        cursor.execute("PRAGMA table_info(devices)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'serial_number' not in columns:
            try:
                print("Adding serial_number column to devices table...")
                # Add column without UNIQUE constraint first (SQLite limitation)
                cursor.execute('ALTER TABLE devices ADD COLUMN serial_number TEXT')
                print("serial_number column added successfully")
            except Exception as e:
                print(f"Warning: Could not add serial_number column: {e}")
                print("This may be normal if the column already exists in some form")
    
    def _migrate_users_table(self, cursor):
        """Migrate existing users table to add new columns"""
        # Check if columns already exist
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]

        if 'serial_number' not in columns:
            try:
                print("Adding serial_number column to users table...")
                cursor.execute('ALTER TABLE users ADD COLUMN serial_number TEXT')
                print("serial_number column added to users table successfully")
            except Exception as e:
                print(f"Warning: Could not add serial_number column to users table: {e}")
                print("This may be normal if the column already exists in some form")

        if 'external_user_id' not in columns:
            try:
                print("Adding external_user_id column to users table...")
                cursor.execute('ALTER TABLE users ADD COLUMN external_user_id INTEGER NULL')
                print("external_user_id column added to users table successfully")
            except Exception as e:
                print(f"Warning: Could not add external_user_id column to users table: {e}")

        if 'avatar_url' not in columns:
            try:
                print("Adding avatar_url column to users table...")
                cursor.execute('ALTER TABLE users ADD COLUMN avatar_url TEXT NULL')
                print("avatar_url column added to users table successfully")
            except Exception as e:
                print(f"Warning: Could not add avatar_url column to users table: {e}")
    
    def _migrate_attendance_logs_table(self, cursor):
        """Migrate existing attendance_logs table to add sync tracking columns and unique constraint"""
        # Check if columns already exist
        cursor.execute("PRAGMA table_info(attendance_logs)")
        columns = [column[1] for column in cursor.fetchall()]
        column_names = [column[1] for column in cursor.fetchall()]

        if 'serial_number' not in columns:
            try:
                print("Adding serial_number column to attendance_logs table...")
                cursor.execute('ALTER TABLE attendance_logs ADD COLUMN serial_number TEXT')
                print("serial_number column added to attendance_logs table successfully")
            except Exception as e:
                print(f"Warning: Could not add serial_number column to attendance_logs table: {e}")

        # Handle migration from is_synced to sync_status
        if 'sync_status' not in columns:
            if 'is_synced' in columns:
                print("Migrating from is_synced to sync_status...")
                # Add new sync_status column
                cursor.execute('ALTER TABLE attendance_logs ADD COLUMN sync_status TEXT DEFAULT "pending"')

                # Migrate existing data: is_synced=1 -> 'synced', is_synced=0 -> 'pending'
                cursor.execute('''
                    UPDATE attendance_logs
                    SET sync_status = CASE
                        WHEN is_synced = 1 THEN 'synced'
                        ELSE 'pending'
                    END
                ''')
                print("Data migrated from is_synced to sync_status successfully")

                # Note: We keep is_synced column for backward compatibility during transition
                print("Note: is_synced column kept for backward compatibility")
            else:
                print("Adding sync_status column to attendance_logs table...")
                cursor.execute('ALTER TABLE attendance_logs ADD COLUMN sync_status TEXT DEFAULT "pending"')

        if 'is_synced' not in columns:
            print("Adding is_synced column to attendance_logs table...")
            cursor.execute('ALTER TABLE attendance_logs ADD COLUMN is_synced BOOLEAN DEFAULT FALSE')

        if 'synced_at' not in columns:
            print("Adding synced_at column to attendance_logs table...")
            cursor.execute('ALTER TABLE attendance_logs ADD COLUMN synced_at DATETIME NULL')

        # Add error tracking columns for sync error handling
        if 'error_code' not in columns:
            print("Adding error_code column to attendance_logs table...")
            cursor.execute('ALTER TABLE attendance_logs ADD COLUMN error_code TEXT NULL')

        if 'error_message' not in columns:
            print("Adding error_message column to attendance_logs table...")
            cursor.execute('ALTER TABLE attendance_logs ADD COLUMN error_message TEXT NULL')
        
        # Check if unique constraint already exists
        cursor.execute("PRAGMA index_list(attendance_logs)")
        constraints = cursor.fetchall()
        
        unique_constraint_exists = False
        for constraint in constraints:
            if 'unique_attendance' in constraint[1]:
                unique_constraint_exists = True
                break
        
        if not unique_constraint_exists:
            try:
                print("Adding unique constraint to prevent duplicate attendance records...")
                # Note: SQLite doesn't support adding constraints to existing tables directly
                # We'll create a unique index instead, which provides the same functionality
                cursor.execute('''
                    CREATE UNIQUE INDEX IF NOT EXISTS unique_attendance 
                    ON attendance_logs(user_id, device_id, timestamp, method, action)
                ''')
                print("Unique constraint added successfully")
            except Exception as e:
                # If constraint creation fails due to existing duplicates, log it
                print(f"Warning: Could not add unique constraint due to existing duplicates: {e}")
                print("Please clean up duplicate records manually if needed")
    
    def execute_query(self, query: str, params: tuple = ()) -> sqlite3.Cursor:
        """Execute a single query"""
        with self.get_cursor() as cursor:
            cursor.execute(query, params)
            return cursor
    
    def fetch_one(self, query: str, params: tuple = ()) -> Optional[sqlite3.Row]:
        """Fetch single row"""
        with self.get_cursor() as cursor:
            cursor.execute(query, params)
            return cursor.fetchone()
    
    def fetch_all(self, query: str, params: tuple = ()) -> List[sqlite3.Row]:
        """Fetch all rows"""
        with self.get_cursor() as cursor:
            cursor.execute(query, params)
            return cursor.fetchall()
    
    def close_connection(self):
        """Close thread-local connection"""
        if hasattr(self._local, 'connection') and self._local.connection is not None:
            try:
                conn = self._local.connection
                conn.close()

                # Remove from tracking set
                with self._lock:
                    self._connections.discard(conn)
            except Exception as e:
                print(f"Error closing thread-local connection: {e}")
            finally:
                self._local.connection = None

    def close_all_connections(self):
        """Close all tracked connections - called on shutdown"""
        print("DatabaseManager: Closing all connections...")
        closed_count = 0
        error_count = 0

        with self._lock:
            # Create a list copy to avoid modification during iteration
            connections_to_close = list(self._connections)
            # Clear the set
            self._connections.clear()

        for conn in connections_to_close:
            try:
                conn.close()
                closed_count += 1
            except Exception as e:
                error_count += 1
                print(f"Error closing connection: {e}")

        print(f"DatabaseManager: Closed {closed_count} connections, {error_count} errors")

# Global database manager instance
db_manager = DatabaseManager()
