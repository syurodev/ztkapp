import queue

# A simple in-memory queue to hold attendance events.
# This is a thread-safe queue.
events_queue = queue.Queue()
